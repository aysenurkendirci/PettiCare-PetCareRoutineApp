import UIKit

final class PetTypeSelectorView: UIStackView {
    var onSelectionChanged: ((String) -> Void)?

    private let types: [String] = ["Kedi", "Köpek", "Kuş", "Diğer"]
    private var selectedType: String = "Kedi"

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupButtons()
    }

    required init(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupButtons() {
        axis = .horizontal
        spacing = 10
        distribution = .fillEqually

        types.forEach { type in
            let button = UIButton(type: .system)
            button.setTitle(type, for: .normal)
            button.setTitleColor(.white, for: .normal)
            button.backgroundColor = type == selectedType ? .systemPurple : .systemGray4
            button.layer.cornerRadius = 8
            button.tag = types.firstIndex(of: type) ?? 0
            button.addTarget(self, action: #selector(handleTap(_:)), for: .touchUpInside)
            addArrangedSubview(button)
        }
    }

    @objc private func handleTap(_ sender: UIButton) {
        selectedType = types[sender.tag]
        arrangedSubviews.enumerated().forEach { (i, view) in
            guard let btn = view as? UIButton else { return }
            btn.backgroundColor = i == sender.tag ? .systemPurple : .systemGray4
        }
        onSelectionChanged?(selectedType)
    }
}
