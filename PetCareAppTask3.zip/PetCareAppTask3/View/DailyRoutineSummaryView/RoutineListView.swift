import UIKit

final class RoutineListView: UIStackView {
    var onRoutineTapped: ((String) -> Void)?

    override init(frame: CGRect) {
        super.init(frame: frame)
        axis = .vertical
        spacing = 12
    }

    required init(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func update(with routines: [String]) {
        arrangedSubviews.forEach { $0.removeFromSuperview() }
        routines.forEach { routine in
            let card = RoutineCardView(title: routine, icon: UIImage(systemName: "pawprint") ?? UIImage())
            card.onRoutineTapped = { [weak self] in
                self?.onRoutineTapped?(routine)
            }
            addArrangedSubview(card)
        }
    }
}
