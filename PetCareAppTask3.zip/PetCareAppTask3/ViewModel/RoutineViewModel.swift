import Foundation

final class RoutineViewModel {

    // MARK: - Properties
    private(set) var selectedPetType: PetType = .cat
    private(set) var selectedDate: Date = Date()
    private var allRoutines: [DailyRoutine] = []

    // MARK: - Selection Actions
    func selectPetType(_ type: PetType) {
        selectedPetType = type
    }

    func selectDate(_ date: Date) {
        selectedDate = date
    }

    func addRoutine(_ routine: Routine) {
        if let index = allRoutines.firstIndex(where: { $0.date == selectedDate && $0.petType == selectedPetType }) {
            allRoutines[index].routines.append(routine)
        } else {
            let newRoutine = DailyRoutine(date: selectedDate, petType: selectedPetType, routines: [routine])
            allRoutines.append(newRoutine)
        }
    }

    // MARK: - Static Data
    func getPredefinedRoutines() -> [Routine] {
        switch selectedPetType {
        case .cat:
            return [
                Routine(title: "Mama", iconName: "cat.fill"),
                Routine(title: "Tuvalet", iconName: "tray.fill"),
                Routine(title: "Oyun", iconName: "gamecontroller.fill")
            ]
        case .dog:
            return [
                Routine(title: "Yürüyüş", iconName: "figure.walk"),
                Routine(title: "Mama", iconName: "dog.fill"),
                Routine(title: "Tüy tarama", iconName: "scissors")
            ]
        case .bird:
            return [
                Routine(title: "Tüy kontrol", iconName: "wind"),
                Routine(title: "Kafes temizliği", iconName: "trash.fill")
            ]
        case .others:
            return [
                Routine(title: "Genel kontrol", iconName: "staroflife.fill")
            ]
        }
    }

    // MARK: - Daily Summary
    func getRoutinesForSelectedDate() -> [Routine] {
        if let match = allRoutines.first(where: { $0.date == selectedDate && $0.petType == selectedPetType }) {
            return match.routines
        }
        return []
    }
}
