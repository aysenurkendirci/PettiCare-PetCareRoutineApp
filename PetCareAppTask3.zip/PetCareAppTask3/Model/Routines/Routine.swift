//
//  Routine.swift
//  PetCareAppTask3
//
//  Created by Ayşe Nur Kendirci on 29.07.2025.
//

import Foundation


enum PetType: String, CaseIterable {
    case cat = "Cat"
    case dog = "Dog"
    case bird = "Bird"
    case others = "Others"
}

struct Routine {
    let title: String
    let iconName: String
}

struct DailyRoutine {
    let date: Date
    let petType: PetType
    var routines: [Routine]
}
