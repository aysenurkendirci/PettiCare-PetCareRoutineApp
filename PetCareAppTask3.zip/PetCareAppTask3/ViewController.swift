//
//  ViewController.swift
//  PetCareAppTask3
//
//  Created by Ayşe Nur Kendirci on 24.07.2025.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

